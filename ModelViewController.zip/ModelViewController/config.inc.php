<?php
// Konfigurationsdatei

# MySQL-Login Daten
# TODO Datenbankverbindung erstezen
define( 'MYSQL_HOST', 'localhost' );
define( 'MYSQL_USER', '' );
define( 'MYSQL_PASS', '' );
define( 'MYSQL_DB', '' );